/*
package Exercise;
*/

public interface Browsable {
    String browse();
}
