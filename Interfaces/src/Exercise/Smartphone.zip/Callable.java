/*
package Exercise;
*/

public interface Callable {
    String call();
}
